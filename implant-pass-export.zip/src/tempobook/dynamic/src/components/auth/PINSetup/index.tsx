
            import PINSetup from "./../../../../../../components/auth/PINSetup.tsx";

            const TempoComponent = () => {
              return <PINSetup />;
            }

            

            export default TempoComponent;