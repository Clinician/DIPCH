
            import AuthScreen from "./../../../../../../components/auth/AuthScreen.tsx";

            const TempoComponent = () => {
              return <AuthScreen />;
            }

            

            export default TempoComponent;