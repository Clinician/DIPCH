
            import PINEntry from "./../../../../../../components/auth/PINEntry.tsx";

            const TempoComponent = () => {
              return <PINEntry />;
            }

            

            export default TempoComponent;