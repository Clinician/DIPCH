
            import QRScanner from "./../../../../../../components/scanner/QRScanner.tsx";

            const TempoComponent = () => {
              return <QRScanner />;
            }

            

            export default TempoComponent;