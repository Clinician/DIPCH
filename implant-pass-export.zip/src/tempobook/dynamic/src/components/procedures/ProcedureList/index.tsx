
            import ProcedureList from "./../../../../../../components/procedures/ProcedureList.tsx";

            const TempoComponent = () => {
              return <ProcedureList />;
            }

            

            export default TempoComponent;