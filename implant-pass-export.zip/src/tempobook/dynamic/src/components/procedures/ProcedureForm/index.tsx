
            import ProcedureForm from "./../../../../../../components/procedures/ProcedureForm.tsx";

            const TempoComponent = () => {
              return <ProcedureForm />;
            }

            

            export default TempoComponent;