
            import ProcedureDetail from "./../../../../../../components/procedures/ProcedureDetail.tsx";

            const TempoComponent = () => {
              return <ProcedureDetail />;
            }

            

            export default TempoComponent;