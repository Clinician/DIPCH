
            import Dashboard from "./../../../../../../components/dashboard/Dashboard.tsx";

            const TempoComponent = () => {
              return <Dashboard />;
            }

            

            export default TempoComponent;