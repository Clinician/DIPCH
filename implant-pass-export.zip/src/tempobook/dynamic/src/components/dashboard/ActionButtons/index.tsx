
            import ActionButtons from "./../../../../../../components/dashboard/ActionButtons.tsx";

            const TempoComponent = () => {
              return <ActionButtons />;
            }

            

            export default TempoComponent;