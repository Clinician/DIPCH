import React, { useState } from "react";
import BluetoothScanner from "../../../components/scanner/BluetoothScanner";
import { Button } from "../../../components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card";

export default function BluetoothScannerDemo() {
  const [showScanner, setShowScanner] = useState(false);
  const [scannerType, setScannerType] = useState<"article" | "lot">("article");
  const [scannedValues, setScannedValues] = useState<{
    article?: string;
    lot?: string;
  }>({});

  const handleScanComplete = (data: string) => {
    console.log(`Scan complete with ${scannerType} data:`, data);

    if (scannerType === "article") {
      setScannedValues((prev) => ({ ...prev, article: data }));
    } else {
      setScannedValues((prev) => ({ ...prev, lot: data }));
    }
  };

  return (
    <div className="p-6 bg-white">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Bluetooth Scanner Demo</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium mb-1">Article Number</p>
              <div className="flex">
                <input
                  type="text"
                  value={scannedValues.article || ""}
                  readOnly
                  className="flex-1 px-3 py-2 border rounded-l-md"
                />
                <Button
                  onClick={() => {
                    setScannerType("article");
                    setShowScanner(true);
                  }}
                  className="rounded-l-none"
                >
                  Scan
                </Button>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium mb-1">Lot Number</p>
              <div className="flex">
                <input
                  type="text"
                  value={scannedValues.lot || ""}
                  readOnly
                  className="flex-1 px-3 py-2 border rounded-l-md"
                />
                <Button
                  onClick={() => {
                    setScannerType("lot");
                    setShowScanner(true);
                  }}
                  className="rounded-l-none"
                >
                  Scan
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-md">
            <p className="text-sm">Instructions:</p>
            <ul className="text-xs text-gray-600 list-disc pl-4 mt-1">
              <li>Click on either Scan button to open the scanner</li>
              <li>The scanner will automatically activate</li>
              <li>
                After scanning, you can scan multiple values without
                reactivating
              </li>
              <li>Values will appear in the respective fields</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {showScanner && (
        <BluetoothScanner
          isOpen={showScanner}
          onClose={() => setShowScanner(false)}
          onScanComplete={handleScanComplete}
          scannerType={scannerType}
        />
      )}
    </div>
  );
}
