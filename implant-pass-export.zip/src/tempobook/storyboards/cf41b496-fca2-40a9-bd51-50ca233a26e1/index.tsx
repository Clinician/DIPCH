import React from "react";

const Storyboard5 = () => {
  return <></>;
};

export default Storyboard5;
