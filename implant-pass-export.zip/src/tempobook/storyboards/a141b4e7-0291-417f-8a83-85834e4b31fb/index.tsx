import React from "react";

const Storyboard12 = () => {
  return <></>;
};

export default Storyboard12;
