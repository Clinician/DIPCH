import React from "react";

const Storyboard10 = () => {
  return <></>;
};

export default Storyboard10;
