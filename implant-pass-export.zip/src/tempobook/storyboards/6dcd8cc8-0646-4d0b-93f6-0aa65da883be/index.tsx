import React from "react";
import ExportGuide from "../../../components/export/ExportGuide";

export default function ExportGuideStoryboard() {
  return (
    <div className="bg-white min-h-screen">
      <ExportGuide />
    </div>
  );
}
