import React from "react";

const Storyboard4 = () => {
  return <></>;
};

export default Storyboard4;
