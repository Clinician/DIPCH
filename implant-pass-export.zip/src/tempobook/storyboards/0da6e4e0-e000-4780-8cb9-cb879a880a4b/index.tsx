import React from "react";

const Storyboard3 = () => {
  return <></>;
};

export default Storyboard3;
