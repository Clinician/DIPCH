import React from "react";

const Storyboard7 = () => {
  return <></>;
};

export default Storyboard7;
