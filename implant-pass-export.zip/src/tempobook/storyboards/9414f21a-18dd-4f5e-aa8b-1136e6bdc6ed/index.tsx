import React from "react";

const Storyboard8 = () => {
  return <></>;
};

export default Storyboard8;
