import React from "react";

const Bluetoothscannerfix = () => {
  return <div />;
};

export default Bluetoothscannerfix;
