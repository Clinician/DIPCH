import React from "react";
import Home from "../../../components/home";
import { ProcedureProvider } from "../../../context/ProcedureContext";

export default function UpdatedDemo() {
  return (
    <ProcedureProvider>
      <Home userName="Demo User" />
    </ProcedureProvider>
  );
}
