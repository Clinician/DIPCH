import React from "react";

const Storyboard15 = () => {
  return <></>;
};

export default Storyboard15;
