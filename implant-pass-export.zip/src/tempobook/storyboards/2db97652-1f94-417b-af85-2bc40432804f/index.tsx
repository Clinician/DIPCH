import React from "react";

const Storyboard9 = () => {
  return <></>;
};

export default Storyboard9;
