import React from "react";

const Storyboard13 = () => {
  return <></>;
};

export default Storyboard13;
