import React, { useState } from "react";
import BluetoothScanner from "@/components/scanner/BluetoothScanner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function BluetoothScannerFixDemo() {
  const [isOpen, setIsOpen] = useState(true);
  const [scannedValues, setScannedValues] = useState<
    { type: string; value: string }[]
  >([]);
  const [scannerType, setScannerType] = useState<"article" | "lot">("article");

  const handleScanComplete = (data: string) => {
    setScannedValues((prev) => [...prev, { type: scannerType, value: data }]);
    // Toggle scanner type for next scan
    setScannerType(scannerType === "article" ? "lot" : "article");
  };

  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <Card className="max-w-md mx-auto mb-4">
        <CardHeader>
          <CardTitle>Bluetooth Scanner Demo</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={() => setIsOpen(true)}>Open Scanner</Button>

          {scannedValues.length > 0 && (
            <div className="mt-4">
              <h3 className="font-medium mb-2">Scanned Values:</h3>
              <div className="space-y-2">
                {scannedValues.map((item, index) => (
                  <div key={index} className="p-2 bg-gray-50 rounded border">
                    <span className="font-medium">
                      {item.type.toUpperCase()}:
                    </span>{" "}
                    {item.value}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <BluetoothScanner
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onScanComplete={handleScanComplete}
        scannerType={scannerType}
      />
    </div>
  );
}
